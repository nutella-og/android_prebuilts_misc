const char CCACHE_VERSION[] = "3.2.4";
